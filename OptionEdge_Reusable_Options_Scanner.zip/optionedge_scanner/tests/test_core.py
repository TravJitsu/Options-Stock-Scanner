import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import unittest
from datetime import date
import numpy as np
import pandas as pd
from core import (Settings, black_scholes_call, distinct_touches, evaluate_option_chain,
                  option_scenarios, journal_stats, price_analysis)

class ScannerTests(unittest.TestCase):
    def test_risk_cap(self):
        s=Settings(max_premium_usd=180,account_equity_usd=1000,risk_pct=2)
        self.assertEqual(s.hard_premium_cap,20)

    def test_black_scholes_standard_example(self):
        call=black_scholes_call(100,100,1,.2,.05)
        self.assertAlmostEqual(call['value'],10.4506,places=3)
        self.assertAlmostEqual(call['delta'],.6368,places=3)
        self.assertLess(call['theta_day'],0)

    def test_touches_group_distinct_sessions(self):
        low=pd.Series([101,100.4,99.9,102,103,104,101,100.2,100,99.5,104,105])
        self.assertEqual(distinct_touches(low,100,2.5,gap=5),2)

    def test_contract_rejection_follows_cap(self):
        s=Settings(account_equity_usd=1000,risk_pct=2,max_premium_usd=180,
                   min_delta=.01,max_delta=.99,min_open_interest=10)
        c=pd.DataFrame([{'strike':95,'bid':1.4,'ask':1.8,'impliedVolatility':.4,
                         'openInterest':1000,'volume':30,'contractSymbol':'TEST'}])
        opt=evaluate_option_chain('TEST','2027-05-21',c,100,.3,s,
                                   today=date(2026,10,16))[0]
        self.assertEqual(opt['Max loss 1 contract $'],180.)
        self.assertIn('Exceeds premium',opt['Reject / review reasons'])

    def test_missing_option_quotes_skip(self):
        c=pd.DataFrame([{'strike':95,'bid':0,'ask':1,'impliedVolatility':.4}])
        self.assertEqual(evaluate_option_chain('X','2027-05-21',c,100,.2,Settings(),today=date(2026,10,16)),[])

    def test_derived_scenarios(self):
        df=option_scenarios(100,95,.3,8,120,days_passed=30)
        self.assertEqual(len(df),15)
        self.assertIn('P/L per contract $',df)

    def test_journal_stats(self):
        df=pd.DataFrame({'Realized P/L $':[100,-50,60,-20]})
        stats=journal_stats(df)
        self.assertEqual(stats['Trades'],4)
        self.assertEqual(stats['Win rate %'],50.)
        self.assertEqual(stats['Expectancy $/trade'],22.5)

    def test_prices_generate_defined_status(self):
        dates=pd.bdate_range(end=pd.Timestamp.today().normalize(),periods=320)
        x=np.linspace(60,54,320)+.4*np.sin(np.linspace(0,35,320))
        h=pd.DataFrame({'Open':x-.08,'High':x+.4,'Low':x-.4,'Close':x,'Volume':1e6},index=dates)
        result=price_analysis('FAKE',h,h,Settings())
        self.assertIn(result['Status'],('SETUP','WATCH','NO MATCH'))
        self.assertEqual(result['Ticker'],'FAKE')

if __name__=='__main__':unittest.main()

class DataAdapterTests(unittest.TestCase):
    def test_all_symbols_missing_data_is_handled_gracefully(self):
        from unittest.mock import patch
        import types
        from data_access import fetch_stock_results
        with patch.dict(sys.modules,{'yfinance':types.ModuleType('yfinance')}):
            with patch('data_access.fetch_histories',return_value={}):
                frame,metadata,prices,errors=fetch_stock_results(['FAKE1','FAKE2'],Settings())
        self.assertEqual(len(frame),2)
        self.assertEqual(set(frame['Status']),{'DATA ERROR'})
        self.assertTrue(errors)

    def test_all_non_matching_rows_is_handled(self):
        from unittest.mock import patch
        import types
        from data_access import fetch_stock_results
        import numpy as np
        date_range=pd.bdate_range(end=pd.Timestamp.today().normalize(),periods=320)
        price=np.linspace(30,70,320)
        history=pd.DataFrame({'Open':price,'High':price+.5,'Low':price-.5,
                              'Close':price,'Volume':1000000},index=date_range)
        with patch.dict(sys.modules,{'yfinance':types.ModuleType('yfinance')}):
            with patch('data_access.fetch_histories',return_value={'FAKE':history,'SPY':history}):
                frame,metadata,prices,errors=fetch_stock_results(['FAKE'],Settings(max_stock_price=20))
        self.assertEqual(frame.iloc[0]['Status'],'NO MATCH')
        self.assertEqual(frame.iloc[0]['Fundamental score /12'],0)
