"""Repeatable command-line scanner; saves dated CSVs. Run from an OS scheduler if desired."""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import sys
from core import Settings
from data_access import DEFAULT_WATCHLIST, clean_symbols, fetch_options, fetch_stock_results


def main():
    parser=argparse.ArgumentParser(description='OptionEdge long-call setup scanner')
    parser.add_argument('--tickers',default=DEFAULT_WATCHLIST,help='Comma-separated ticker symbols')
    parser.add_argument('--watchlist-file',help='Text file containing tickers (space/comma/newline separated)')
    parser.add_argument('--stock-min',type=float,default=5)
    parser.add_argument('--stock-max',type=float,default=100)
    parser.add_argument('--budget',type=float,default=180)
    parser.add_argument('--account-equity',type=float,default=10000,help='Illustrative default; replace with real account size')
    parser.add_argument('--risk-pct',type=float,default=2)
    parser.add_argument('--max-option-stocks',type=int,default=8)
    parser.add_argument('--stocks-only',action='store_true')
    parser.add_argument('--output-dir',default='reports')
    args=parser.parse_args()
    raw=Path(args.watchlist_file).read_text() if args.watchlist_file else args.tickers
    symbols=clean_symbols(raw)
    if not symbols:parser.error('No valid tickers')
    settings=Settings(min_stock_price=args.stock_min,max_stock_price=args.stock_max,
                      max_premium_usd=args.budget,account_equity_usd=args.account_equity,
                      risk_pct=args.risk_pct,max_option_stocks=max(1,args.max_option_stocks))
    if settings.hard_premium_cap<=0:parser.error('Non-positive risk cap')
    timestamp=datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_UTC')
    target=Path(args.output_dir)/timestamp
    target.mkdir(parents=True,exist_ok=True)
    try:
        stocks,metadata,prices,errors=fetch_stock_results(symbols,settings,
            progress=lambda n,msg: print(f'[{n:5.0%}] {msg}',flush=True))
        stocks.to_csv(target/'stocks.csv',index=False)
        print('\nStock statuses:\n'+stocks['Status'].value_counts().to_string())
        if not args.stocks_only:
            options,opt_errors=fetch_options(stocks,metadata,settings,
                progress=lambda n,msg: print(f'[Contracts {n:5.0%}] {msg}',flush=True))
            errors+=opt_errors
            options.to_csv(target/'options.csv',index=False)
            if options.empty:print('No usable option contracts returned.')
            else:
                review=options[options['Contract status']=='REVIEW']
                print(f'Contracts passing numeric gates: {len(review)}')
                if not review.empty:
                    print(review[['Ticker','Expiration','Strike','Ask','Spread %',
                                  'Max loss 1 contract $','Earnings risk']].head(15).to_string(index=False))
        (target/'warnings.txt').write_text('\n'.join(errors) if errors else 'None\n')
        print(f'\nSaved reports to {target.resolve()}')
    except Exception as exc:
        print(f'Data request failed: {exc}',file=sys.stderr)
        return 1
    return 0

if __name__=='__main__':raise SystemExit(main())
