# OptionEdge — reusable stocks + call-options research scanner

A runnable **Streamlit dashboard** for a user-defined US stock watchlist. This is source code, not a live hosted service. To scan fresh market data, run it on a computer/server with a network connection. You can open the hosted page on your phone after deploying it on Streamlit Community Cloud, but this ZIP alone cannot run inside an iPhone browser.

## Quick start

1. Install Python 3.10 or later.
2. Unzip this folder and open Terminal/PowerShell in the `optionedge_scanner` folder.
3. Run:

   ```bash
   python -m pip install -r requirements.txt
   python -m streamlit run app.py
   ```

4. Your browser opens with the dashboard. Replace the **account equity example** ($10,000) with your actual trading-account equity. Set your max premium and risk percent. Enter tickers and select **Run new scan**.
5. Inspect **stock ranking**, **option chains**, **rejection reasons**, **scenario lab**, and journal; download stock and option CSVs to keep dated records yourself.

## Deploy for use from your phone

Create a private repository with these files on a supported code host (e.g., GitHub) and deploy `app.py` as the app entry point on [Streamlit Community Cloud](https://share.streamlit.io/). Data should be for permitted personal use and journal data in shared/cloud deployments needs private persistent storage. Community Cloud files can be ephemeral. Never deploy your private journal publicly. If you only use the app locally, it stores journal entries in `data/trade_journal.csv`.

## Screening methodology

**Phase 1: Daily bars**. Requires 280 days of trading data. Uses 20, 63, 126, and 252-day historical swing-window lows (excluding the last five daily bars), 2+ nearby windows by default, at least 1 completed weekly/monthly support area, 2+ distinct prior touches of historical support (separated by 5 trading sessions), price near the trailing 90-session low, an improving MACD histogram, and a bullish close versus previous close and today's open. Outputs SETUP, WATCH, NO MATCH or DATA ERROR. Stocks with stale last bars (>7 calendar days) do not pass. No look-ahead data is used in the price tests.

**Phase 2: Fundamentals** for a subset of stock candidates only. Uses reported revenue growth, profit margin, FCF, cash/debt ratio, and 21-day sector ETF versus SPY. Financial information may be missing or lagged.

**Phase 3: Listed US call contracts** for the top (configurable) 1–25 SETUP/WATCH tickers. Evaluates DTE, ITM, modeled Delta (default .55–.75), asking-price max premium, OI, spread %, IV over realized 20-day volatility, and known forward earnings dates if available. The app keeps rejection explanations. Passing contracts are labeled **REVIEW**, not BUY.

**Methodological honesty:** Support windows overlap; points are a heuristic *ranking*, not probabilities, audited backtest results, recommendations, or proof of positive expectancy. Delta, Theta and Vega are model approximations (European Black-Scholes, zero dividend yield, assumed 4% risk-free rate). US equity call options are typically American exercise; actual fair prices can differ. Implied versus realized volatility is *not* historical IV rank. No news/catalyst search, true probability-of-profit calculation, reliable earnings-calendar check or execution automation. User must verify all event risks and quotes at the brokerage.

## Cost / risk caps

The scanner uses `min(max_contract_premium, account_equity * risk_percent / 100)` as the **effective** maximum possible loss per one long call; options may still have commissions, fees and slippage. An option listed at ask $1.80 costs about $180 for one standard 100-share contract, excluding fees. **Max loss on a fully paid long call can be 100% of the premium.** Stops are not guaranteed. If you set account equity $180 and max risk 2%, the scanner correctly finds no $180 long calls because one such call risks the whole account.

## Why a scan may return 0 candidates

1. The setup and affordable 0.55–0.75-Delta contract requirements can be genuinely restrictive.
2. Yahoo data sources can be rate-limited or missing contracts/fundamentals.
3. Your candidate stocks may trade well above the configured price range.
4. A weekend or holiday can produce outdated data. Last-price dates appear in results.

Widen only the criteria you intentionally understand; do **not** assume a favorable opportunity must exist every day. Start with 15–40 tickers so data requests are less likely to be throttled. No API key is needed, but data access is not guaranteed.

## Sample pre-trade human checklist

- Confirm price/quotes and available fill with your broker.
- Verify exact earnings day, guidance, corporate actions, major news, regulatory events and sector developments.
- Read company filings for revenue, earnings quality, cash flow, valuation, liabilities and catalysts.
- Choose entry, invalidation price, exit target and a time-stop *before* the purchase.
- Record expected rewards/losses and a range of stock-price/IV scenarios.
- If a trade fails your rules or the risk budget, skip it.

## Automated recurrence

You can rerun the dashboard on demand. The included command-line scanner also saves a time-stamped CSV report, so it can be started manually or by an **external** scheduler:

```bash
python scan_cli.py --tickers "SOFI,NU,DKNG,AMD,PYPL" --budget 180 --account-equity 5000 --risk-pct 2
```

To scan your own saved list, use `--watchlist-file tickers.txt`; to skip option-chain requests, use `--stocks-only`. Reports land in `reports/YYYYMMDD_HHMMSS_UTC/`. If you want automatic runs, configure your own computer's Task Scheduler or cron to invoke this command. The files alone do not create background tasks, send alerts or execute trades.

## Tests

With dependencies installed:

```bash
python -m unittest discover -s tests -v
```

The core module can be unit-tested without a live market connection; live Yahoo/Streamlit integration depends on a working internet connection and optional third-party services.
