"""OptionEdge — a research-oriented stock-and-long-call scanner."""
from __future__ import annotations
from datetime import date, datetime, timezone
from pathlib import Path
import io
import pandas as pd
import streamlit as st
import plotly.graph_objects as go

from core import Settings, black_scholes_call, journal_stats, option_scenarios
from data_access import DEFAULT_WATCHLIST, clean_symbols, fetch_stock_results, fetch_options

st.set_page_config(page_title='OptionEdge | Options Scanner',page_icon='📈',layout='wide')
st.markdown('''<style>
.block-container{padding-top:1.5rem;max-width:1460px}
h1{letter-spacing:-.04em}
[data-testid="stMetricValue"]{font-size:1.55rem}
</style>''',unsafe_allow_html=True)

st.title('OptionEdge')
st.caption('SUPPORT-BOUNCE STOCK SCANNER + LONG CALL RESEARCH LAB  •  Educational tool, not personalized investment advice')
st.warning('**Important:** This app ranks research candidates; it cannot guarantee profitability or verify every catalyst. Yahoo-derived quotes may be delayed or unavailable. Verify market/option quotes, earnings, corporate events and liquidity with your broker before trading.', icon='⚠️')

with st.sidebar:
    st.header('Your screening profile')
    symbols_raw=st.text_area('Stock universe — comma or space separated',value=DEFAULT_WATCHLIST,height=185)
    symbols=clean_symbols(symbols_raw)
    st.caption(f'{len(symbols)} unique symbols. Start with 15–40 for more reliable data access.')
    with st.expander('Stock setup filters',expanded=True):
        price_range=st.slider('Stock price ($)',1,300,(5,100))
        low_pct=st.slider('Maximum above 90-day low (%)',2,50,20)
        support_tol=st.slider('Support proximity tolerance (%)',1.0,10.0,4.0,0.5)
        support_count=st.slider('Minimum aligned lookback windows',1,4,2)
        min_touches=st.slider('Minimum historical support tests',1,4,2)
        require_htf=st.checkbox('Require completed weekly or monthly support too',value=True)
    with st.expander('Contract + risk filters',expanded=True):
        max_cost=st.number_input('Max call premium, one contract ($)',min_value=20,max_value=20000,value=180,step=20)
        equity=st.number_input('Your account equity ($) — replace example',min_value=20,max_value=10000000,value=10000,step=100)
        risk=st.slider('Maximum full-premium risk as % of account',0.5,10.0,2.0,0.5)
        dte_range=st.slider('Days until expiration',14,730,(60,240),step=1)
        delta_range=st.slider('Approx. call delta',0.10,0.95,(0.55,0.75),step=0.05)
        min_oi=st.number_input('Minimum call open interest',min_value=0,max_value=10000,value=100,step=50)
        max_spread=st.slider('Maximum bid-ask spread (%)',2,50,18)
        max_iv_rv=st.slider('Maximum IV / realized volatility ratio',0.6,5.0,2.0,0.1)
    with st.expander('Scan volume'):
        include_watch=st.checkbox('Include not-yet-confirmed WATCH setups in contract searches',value=True)
        option_stock_limit=st.slider('Max tickers to check for options',1,25,8)
        expiries_limit=st.slider('Max expirations per ticker',1,10,5)
    settings=Settings(min_stock_price=float(price_range[0]),max_stock_price=float(price_range[1]),
       max_above_90d_low_pct=float(low_pct), support_tolerance_pct=float(support_tol),
       minimum_support_windows=support_count,minimum_support_touches=min_touches,
       require_higher_timeframe_support=require_htf,
       max_premium_usd=float(max_cost),account_equity_usd=float(equity),risk_pct=float(risk),
       min_dte=int(dte_range[0]),max_dte=int(dte_range[1]),
       min_delta=float(delta_range[0]),max_delta=float(delta_range[1]),
       min_open_interest=int(min_oi),max_spread_pct=float(max_spread),
       max_iv_rv_ratio=float(max_iv_rv),include_watch=include_watch,
       max_option_stocks=option_stock_limit,max_expirations_per_stock=expiries_limit)
    st.metric('Effective one-contract risk cap',f'${settings.hard_premium_cap:,.0f}')
    st.caption('Minimum of your premium budget and your percentage-of-equity full-loss limit. Uses the asking price, before fees.')

if 'stocks' not in st.session_state:st.session_state.stocks=pd.DataFrame()
if 'options' not in st.session_state:st.session_state.options=pd.DataFrame()
if 'price_map' not in st.session_state:st.session_state.price_map={}
if 'scan_errors' not in st.session_state:st.session_state.scan_errors=[]
if 'scan_time' not in st.session_state:st.session_state.scan_time=None
if 'scan_settings' not in st.session_state:st.session_state.scan_settings=settings

scanner, lab, journal, instructions=st.tabs(['🔎 Scanner','🧪 Contract scenario lab','📔 Trading journal','ℹ️ Method / limitations'])

with scanner:
    a,b,c=st.columns([2,1,1])
    with a: scan=st.button('Run new scan',type='primary',use_container_width=True)
    with b: st.metric('Symbols to inspect',len(symbols))
    with c: st.metric('Contract risk ceiling',f'${settings.hard_premium_cap:,.0f}')
    if scan:
        if not symbols:st.error('Add at least one ticker to the universe.')
        else:
            bar=st.progress(0,text='Connecting to historical market data…')
            def price_progress(percent,msg):bar.progress(min(100,int(percent*100)),text=msg)
            try:
                stocks,metadata,prices,errors=fetch_stock_results(symbols,settings,progress=price_progress)
                bar.progress(95,text='Checking option chains for highest-ranked setups…')
                options,opt_errors=fetch_options(stocks,metadata,settings)
                st.session_state.stocks=stocks
                st.session_state.options=options
                st.session_state.price_map=prices
                st.session_state.scan_errors=errors+opt_errors
                st.session_state.scan_settings=settings
                st.session_state.scan_time=datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
                bar.progress(100,text='Scan complete')
                st.success('Scan finished. Review the technical candidates and the contract rejection reasons below.')
            except ImportError:
                st.error('Missing packages: run `pip install -r requirements.txt` on the machine hosting the app.')
            except Exception as exc:
                st.error(f'Market data request failed: {exc}. Retry fewer symbols or try again later; no stale result was relabeled as fresh.')
    stocks=st.session_state.stocks
    options=st.session_state.options
    if st.session_state.scan_time:st.caption('Last completed scan: '+st.session_state.scan_time+' • Changing filters requires running a new scan.')
    if not stocks.empty:
        candidates=stocks[stocks['Status']=='SETUP']
        watch=stocks[stocks['Status']=='WATCH']
        contracts_review=options[options['Contract status']=='REVIEW'] if not options.empty else pd.DataFrame()
        c1,c2,c3,c4=st.columns(4)
        c1.metric('Confirmed setup candidates',len(candidates))
        c2.metric('Support watchlist',len(watch))
        c3.metric('Contracts passing numeric gates',len(contracts_review))
        c4.metric('Data errors',int((stocks['Status']=='DATA ERROR').sum()))
        st.subheader('Stock ranking')
        st.caption('Heuristic scores rank setups, NOT win probabilities. A WATCH setup has not confirmed its bounce. Score combines up to 80 technical and 12 fundamental points; 8 additional contract points appear in option results.')
        select_status=st.multiselect('Show statuses',['SETUP','WATCH','NO MATCH','DATA ERROR'],default=['SETUP','WATCH'])
        shown=stocks[stocks['Status'].isin(select_status)]
        priority=['Ticker','Status','Combined score /100','Technical score /80','Price',
          'Above 90d low %','Confluence','Higher TF confluence','Support zone $','Prior touches',
          'RSI14','MACD improving','Relative volume','vs SPY 21d %',
          'Fundamental score /12','Fundamental coverage','Upcoming earnings','Reason']
        st.dataframe(shown[[c for c in priority if c in shown]],use_container_width=True,hide_index=True)
        st.download_button('Download full stock scan (CSV)',stocks.to_csv(index=False).encode(),file_name='optionedge_stock_scan.csv',mime='text/csv')
        if len(stocks)>0:
            available=[t for t in stocks['Ticker'].tolist() if t in st.session_state.price_map]
            if available:
                selected=st.selectbox('Inspect a stock chart',available)
                hist=st.session_state.price_map[selected].tail(160)
                fig=go.Figure(data=[go.Candlestick(x=hist.index,open=hist.Open,high=hist.High,low=hist.Low,close=hist.Close,name=selected)])
                level=stocks.loc[stocks['Ticker']==selected,'Support zone $']
                if not level.empty and pd.notna(level.iloc[0]):
                    fig.add_hline(y=float(level.iloc[0]),line_dash='dash',line_color='#f59e0b',annotation_text='Historical support')
                fig.update_layout(height=410,margin=dict(l=10,r=10,t=20,b=20),xaxis_rangeslider_visible=False)
                st.plotly_chart(fig,use_container_width=True)
                st.caption('Daily OHLC support is computed using price action BEFORE the last five daily bars to reduce manufactured support levels.')
        st.subheader('Long-call contracts')
        if options.empty:
            st.info('No usable option-chain rows found. This can mean no setups met the filters, no available expirations, or market data was unavailable. Stock candidates above can still be studied.')
        else:
            review_only=st.toggle('Show only contracts that pass numeric filters',value=True)
            view=options[options['Contract status']=='REVIEW'] if review_only else options
            columns=['Ticker','Expiration','DTE','Strike','Ask','Max loss 1 contract $',
                     'Delta (model)','IV %','IV / RV20','Spread %','Open interest',
                     'Breakeven at expiry $','Contract status','Combined score /100',
                     'Earnings risk','Reject / review reasons']
            st.dataframe(view[[c for c in columns if c in view]],hide_index=True,use_container_width=True)
            if view.empty:st.info('No contracts pass ALL numeric limits. Change a constraint deliberately, or skip trading; never force a contract to fit the budget.')
            st.download_button('Download full options scan (including rejections)',options.to_csv(index=False).encode(),file_name='optionedge_options_scan.csv',mime='text/csv')
            st.caption('A REVIEW result has passed numeric gates only; it is **not** approved for trading. Earnings, news and events still require a human check.')
    if st.session_state.scan_errors:
        with st.expander(f'Data warnings & rejected API requests ({len(st.session_state.scan_errors)})'):
            for item in st.session_state.scan_errors: st.write('• '+item)

with lab:
    st.subheader('Price + volatility scenario testing')
    st.write('Model a contract 7–60 days after purchase under different stock and IV moves. European Black–Scholes is an approximation; actual American-style option prices, dividends, spreads and early assignment risk may differ.')
    records=st.session_state.options
    if not records.empty:
        choices=records.index.tolist()
        selected_index=st.selectbox('Choose a call from the last scan',choices,
            format_func=lambda i:f"{records.loc[i,'Ticker']} | {records.loc[i,'Expiration']} | ${records.loc[i,'Strike']:g} call | ask ${records.loc[i,'Ask']:.2f}")
        o=records.loc[selected_index]
        ticker=o['Ticker']
        matching=st.session_state.stocks.set_index('Ticker')
        spot=float(matching.loc[ticker,'Price'])
        strike=float(o['Strike']); iv=float(o['IV %'])/100
        ask=float(o['Ask']); dte=int(o['DTE'])
        days=st.slider('Days from now to modeled sale',0,max(1,dte),min(30,max(1,dte)))
        modeled=option_scenarios(spot,strike,iv,ask,dte,
                                 st.session_state.scan_settings.interest_rate,days)
        st.metric('Maximum theoretical loss (one purchased call)',f'${ask*100:,.2f} plus fees')
        approx_move=spot*iv*(max(dte,1)/365)**0.5
        st.caption(f'Approximate market-implied one-standard-deviation move through expiration: ±${approx_move:.2f} in the stock, based on this contract IV. This is NOT a forecast or a guaranteed range.')
        st.markdown('**Define your exit thesis (illustrative model)**')
        col_a,col_b=st.columns(2)
        with col_a: target=st.number_input('Target underlying stock price ($)',min_value=.01,value=float(round(spot*1.08,2)),step=.5)
        with col_b: stop=st.number_input('Technical invalidation stock price ($)',min_value=.01,value=float(round(spot*.96,2)),step=.5)
        if target>stop and stop<spot<target:
            t=max(0,(dte-days)/365)
            target_option=black_scholes_call(target,strike,t,iv,st.session_state.scan_settings.interest_rate)['value']
            stop_option=black_scholes_call(stop,strike,t,iv,st.session_state.scan_settings.interest_rate)['value']
            potential_reward=(target_option-ask)*100
            potential_loss=(ask-stop_option)*100
            ratio=potential_reward/potential_loss if potential_loss>0 else float('nan')
            st.write(f'At **{days} days elapsed** with **unchanged IV**, estimated target P/L: **${potential_reward:+,.2f}**; estimated invalidation P/L: **${-potential_loss:+,.2f}**; hypothetical reward/loss ratio: **{ratio:.2f}×**.' if pd.notna(ratio) else 'The estimated downside under these assumptions is zero or negative; this ratio is not meaningful.')
            st.caption('This is scenario math, not an expected-value estimate. The stop may gap past your level and actual quotes may differ substantially.')
        else:st.info('Enter a target above spot and invalidation below spot to calculate illustrative reward/risk.')
        st.dataframe(modeled,use_container_width=True,hide_index=True)
        st.download_button('Download scenario table',modeled.to_csv(index=False),file_name='optionedge_scenarios.csv',mime='text/csv')
    else:st.info('Run a scan first. Scenario modeling will appear once option-chain data is available.')

JOURNAL=Path(__file__).parent/'data'/'trade_journal.csv'
JOURNAL_COLUMNS=['Entry date','Exit date','Ticker','Expiration','Strike','Contracts',
                 'Entry ask/share $','Exit price/share $','Fees $','Realized P/L $','Setup','Notes']

def load_journal():
    if JOURNAL.exists():
        try:return pd.read_csv(JOURNAL).reindex(columns=JOURNAL_COLUMNS)
        except Exception:return pd.DataFrame(columns=JOURNAL_COLUMNS)
    return pd.DataFrame(columns=JOURNAL_COLUMNS)

with journal:
    st.subheader('Journal closed long-call trades')
    st.caption('Stored locally on the computer running this app (data/trade_journal.csv). Cloud-hosted temporary storage may not persist; export your journal regularly.')
    with st.form('journal_trade'):
        j1,j2,j3=st.columns(3)
        with j1:
            ticker=st.text_input('Ticker',value='').strip().upper()
            entry_date=st.date_input('Entry date',value=date.today())
            entry=st.number_input('Entry premium per share ($)',min_value=0.01,value=1.80,step=.05)
        with j2:
            expiration=st.date_input('Expiration',value=date.today())
            exit_date=st.date_input('Exit date',value=date.today())
            exit_price=st.number_input('Exit option value per share ($)',min_value=0.0,value=2.10,step=.05)
        with j3:
            strike=st.number_input('Strike ($)',min_value=0.01,value=20.0,step=1.0)
            qty=st.number_input('Number of long call contracts',min_value=1,value=1,step=1)
            fees=st.number_input('All entry/exit trading fees ($)',min_value=0.,value=1.30,step=.10)
        setup=st.selectbox('Setup type',['Support bounce','Breakout','Trend continuation','Other'])
        notes=st.text_area('What was the thesis, invalidation, and actual outcome?')
        add=st.form_submit_button('Save closed trade',type='primary')
    if add:
        if not ticker:st.error('Enter a stock ticker.')
        elif exit_date<entry_date:st.error('Exit date cannot be before entry date.')
        else:
            profit=(float(exit_price)-float(entry))*100*qty-float(fees)
            record=[str(entry_date),str(exit_date),ticker,str(expiration),float(strike),int(qty),
                    float(entry),float(exit_price),float(fees),round(profit,2),setup,notes]
            prior=load_journal()
            updated=pd.concat([prior,pd.DataFrame([dict(zip(JOURNAL_COLUMNS,record))])],ignore_index=True)
            JOURNAL.parent.mkdir(parents=True,exist_ok=True)
            updated.to_csv(JOURNAL,index=False)
            st.success(f'Saved. Realized P/L: ${profit:+,.2f}')
    trades=load_journal()
    if not trades.empty:
        stats=journal_stats(trades)
        if stats:
            st.write('**Measured performance (closed trades only)**')
            cols=st.columns(4)
            for col,(k,v) in zip(cols,list(stats.items())[:4]):col.metric(k,str(v))
            st.write(f"Net P/L: **${stats['Total P/L $']:+,.2f}** • Max realized P/L drawdown: **${stats['Max peak-to-trough drawdown $']:,.2f}**")
            st.caption('Statistics ignore open-position risk, taxes, slippage beyond entered prices, and selection bias. A sample of trades is not proof of future success.')
        st.dataframe(trades,use_container_width=True,hide_index=True)
        st.download_button('Download journal backup (CSV)',trades.to_csv(index=False).encode(),file_name='optionedge_trade_journal.csv',mime='text/csv')
        uploaded=st.file_uploader('Restore/replace journal from exported CSV',type=['csv'])
        if uploaded is not None and st.button('Replace journal with uploaded file'):
            try:
                restored=pd.read_csv(uploaded)
                if not set(JOURNAL_COLUMNS).issubset(restored.columns):raise ValueError('Missing journal columns')
                restored[JOURNAL_COLUMNS].to_csv(JOURNAL,index=False)
                st.success('Journal replaced. Rerun page to refresh the view.')
            except Exception as exc:st.error(f'Unable to restore journal: {exc}')

with instructions:
    st.subheader('What the scanner checks')
    st.markdown('''**Technical:** 20/63/126/252-day *established* price support, completed weekly/monthly support alignment, repeated historical tests, 90-day low proximity, RSI momentum, MACD histogram direction, daily bullish candle, 3-day improvement, relative volume, 50/200-day simple moving averages and relative strength vs SPY.

**Fundamentals and sector:** Revenue growth, profitability, free cash flow, balance sheet liquidity, ETF sector relative strength. Missing information is marked missing rather than guessed.

**Options:** Listed expiration, ITM strike, approximated Delta/Theta/Vega, DTE, asking-price cost, full-premium account risk, IV vs trailing 20-day realized volatility, volume, open interest, spread and expiration breakeven. Rejected contracts remain downloadable.

**Performance:** Log closed trades, then inspect win rate, realized expectancy, profit factor and drawdown.

**Not automatically verified:** Reliable forward earnings/catalyst calendar, news, earnings revisions, institutional flows, corporate actions, live bid/ask execution, dividends in Greek calculations, full historical IV rank/percentile, tested probability of profit, order execution and behavioral discipline. These require independent review, better data, or your trading journal. An IV/realized-volatility ratio is **not** IV rank or a reliable mispricing measure.

**Support confluence caveat:** Overlapping 20/63/126/252-day lookbacks are *correlated*, not four independent proofs. Price can break support; a heuristic score is not a success probability.

**Data source:** `yfinance` (unofficial Yahoo Finance wrapper, for personal research). Availability and quote delays vary. The app makes **no trades** and does not provide notifications or unattended scheduling.''')
