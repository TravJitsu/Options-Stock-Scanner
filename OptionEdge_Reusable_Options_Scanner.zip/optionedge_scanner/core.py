"""OptionEdge: independent, testable calculations. Not a trading signal service."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import date, datetime, timezone
from math import erf, exp, log, pi, sqrt
from typing import Optional
import numpy as np
import pandas as pd


@dataclass
class Settings:
    min_stock_price: float = 5.0
    max_stock_price: float = 100.0
    max_above_90d_low_pct: float = 20.0
    support_tolerance_pct: float = 4.0
    minimum_support_windows: int = 2
    minimum_support_touches: int = 2
    require_higher_timeframe_support: bool = True
    max_premium_usd: float = 180.0
    account_equity_usd: float = 10000.0  # EXAMPLE; replace with actual equity
    risk_pct: float = 2.0
    min_dte: int = 60
    max_dte: int = 240
    min_delta: float = 0.55
    max_delta: float = 0.75
    min_open_interest: int = 100
    max_spread_pct: float = 18.0
    max_iv_rv_ratio: float = 2.0
    interest_rate: float = 0.04
    include_watch: bool = True
    max_option_stocks: int = 8
    max_expirations_per_stock: int = 5

    @property
    def hard_premium_cap(self) -> float:
        return max(0.0, min(self.max_premium_usd, self.account_equity_usd * self.risk_pct / 100.0))


def fnum(val, default=float('nan')) -> float:
    try:
        n = float(val)
        return n if np.isfinite(n) else default
    except (ValueError, TypeError, OverflowError):
        return default


def norm_cdf(x: float) -> float:
    return 0.5 * (1 + erf(x / sqrt(2)))


def norm_pdf(x: float) -> float:
    return exp(-0.5 * x*x) / sqrt(2*pi)


def black_scholes_call(s: float, k: float, t_years: float, vol: float, r: float = 0.04):
    """European call approximation (q=0); real American calls/dividends may differ."""
    if min(s, k) <= 0 or t_years <= 0:
        return {'value': max(0.0, s-k), 'delta': float(s > k), 'theta_day': 0.0,
                'vega_1pct': 0.0, 'gamma': 0.0}
    if vol <= 0:
        val = max(0.0, s-k*exp(-r*t_years))
        return {'value': val, 'delta': float(s > k*exp(-r*t_years)), 'theta_day': 0.0,
                'vega_1pct': 0.0, 'gamma': 0.0}
    root = sqrt(t_years)
    d1 = (log(s/k)+(r+0.5*vol*vol)*t_years)/(vol*root)
    d2 = d1-vol*root
    delta = norm_cdf(d1)
    value = s*delta-k*exp(-r*t_years)*norm_cdf(d2)
    gamma = norm_pdf(d1)/(s*vol*root)
    theta_annual = -(s*norm_pdf(d1)*vol)/(2*root)-r*k*exp(-r*t_years)*norm_cdf(d2)
    vega_1pct = s*norm_pdf(d1)*root/100
    return {'value': max(0.0, value), 'delta': delta, 'theta_day': theta_annual/365,
            'vega_1pct': vega_1pct, 'gamma': gamma}


def rsi(series: pd.Series, n: int = 14) -> pd.Series:
    changes = series.diff()
    gain = changes.clip(lower=0).ewm(alpha=1/n, adjust=False, min_periods=n).mean()
    loss = -changes.clip(upper=0).ewm(alpha=1/n, adjust=False, min_periods=n).mean()
    ratio = gain / loss.replace(0, np.nan)
    result = 100 - 100 / (1 + ratio)
    result = result.mask((loss == 0) & (gain > 0), 100)
    result = result.mask((loss == 0) & (gain == 0), 50)
    return result


def macd_hist(series: pd.Series) -> pd.Series:
    ema12 = series.ewm(span=12, adjust=False).mean()
    ema26 = series.ewm(span=26, adjust=False).mean()
    macd = ema12 - ema26
    return macd - macd.ewm(span=9, adjust=False).mean()


def distinct_touches(low: pd.Series, level: float, tolerance_pct: float, gap: int = 5) -> int:
    """Groups nearby bars into separate tests of the same pre-existing price zone."""
    if not np.isfinite(level) or level <= 0:
        return 0
    points = np.where((low.to_numpy() >= level*(1-tolerance_pct/100)) &
                      (low.to_numpy() <= level*(1+tolerance_pct/100)))[0]
    count, last = 0, -gap
    for point in points:
        if point - last >= gap:
            count += 1
            last = point
    return count


def price_analysis(symbol: str, hist: pd.DataFrame, spy: Optional[pd.DataFrame], settings: Settings):
    """Uses prices only through last completed daily bar, never future prices."""
    required = ['Open','High','Low','Close','Volume']
    if hist is None or hist.empty or any(c not in hist for c in required):
        return {'Ticker': symbol, 'Status': 'DATA ERROR', 'Reason': 'Missing OHLCV history'}
    h = hist[required].dropna(subset=['Open','High','Low','Close']).copy().sort_index()
    if len(h) < 280:
        return {'Ticker': symbol, 'Status': 'DATA ERROR', 'Reason': 'Requires 280 daily bars'}
    close, low, volume = h['Close'], h['Low'], h['Volume'].fillna(0)
    spot = fnum(close.iloc[-1]); previous_close = fnum(close.iloc[-2])
    last_day = pd.Timestamp(h.index[-1]).date().isoformat()
    age_days = (datetime.now(timezone.utc).date() - pd.Timestamp(h.index[-1]).date()).days
    # Exclude the last five bars: current/new lows do not manufacture historical support.
    established_lows = low.iloc[:-5]
    levels = {w: fnum(established_lows.tail(w).min()) for w in (20,63,126,252)}
    support_distances = {w: (spot/v-1)*100 if v > 0 else 999.0 for w,v in levels.items()}
    near = [w for w,d in support_distances.items() if -1.0 <= d <= settings.support_tolerance_pct]
    # Choose a nearby historical support, even if it just broke slightly.
    nearest_level = (levels[min(near, key=lambda w: abs(support_distances[w]))]
                     if near else levels[min(levels, key=lambda w: abs(support_distances[w]))])
    touches = distinct_touches(low.iloc[-131:-5], nearest_level, 2.5, gap=5)
    # Weekly and monthly historical support are computed from *completed* higher timeframe bars.
    # These remain correlated with daily data: confluence is a heuristic, not independent evidence.
    weekly = low.resample('W-FRI').min().iloc[:-1]
    monthly = low.resample('ME').min().iloc[:-1]
    weekly_level = fnum(weekly.tail(13).min()) if len(weekly)>=13 else float('nan')
    monthly_level = fnum(monthly.tail(3).min()) if len(monthly)>=3 else float('nan')
    weekly_gap = (spot/weekly_level-1)*100 if weekly_level>0 else float('nan')
    monthly_gap = (spot/monthly_level-1)*100 if monthly_level>0 else float('nan')
    higher_hits = sum(-1.0<=gap<=settings.support_tolerance_pct for gap in (weekly_gap,monthly_gap))
    low90 = fnum(low.tail(90).min())
    above90 = (spot/low90-1)*100 if low90 > 0 else 999.0
    rsi_series = rsi(close)
    rsi_val, prior_rsi = fnum(rsi_series.iloc[-1]), fnum(rsi_series.iloc[-2])
    macd_series = macd_hist(close)
    hist_inc = bool(macd_series.iloc[-1] > macd_series.iloc[-2])
    sma20, sma50, sma200 = (fnum(close.tail(n).mean()) for n in (20,50,200))
    avg_vol = fnum(volume.iloc[-21:-1].mean())
    relative_vol = fnum(volume.iloc[-1]/avg_vol) if avg_vol > 0 else float('nan')
    three_day_up = bool(spot > fnum(close.iloc[-4]))
    price_reversal = bool(spot > previous_close and spot > fnum(h['Open'].iloc[-1]))
    ret21 = fnum(spot/close.iloc[-22]-1)
    spy_ret21 = float('nan')
    if spy is not None and not spy.empty and 'Close' in spy:
        sc = spy['Close'].dropna()
        if len(sc) >= 22:
            # Align the benchmark with the ticker's price dates (avoids shifted comparisons).
            sc = sc.reindex(close.index, method='ffill').dropna()
            if len(sc) >= 22:
                spy_ret21 = fnum(sc.iloc[-1]/sc.iloc[-22]-1)
    rs21 = (ret21-spy_ret21)*100 if np.isfinite(spy_ret21) else float('nan')
    log_returns = np.log(close/close.shift()).dropna()
    rv20 = fnum(log_returns.tail(20).std(ddof=1) * sqrt(252))
    # Transparent weighted heuristic, not a statistically calibrated probability.
    score = 0
    score += min(3,len(near))*6             # 18
    score += min(3,touches)*3               # 9
    score += 10 if above90<=5 else 7 if above90<=15 else 3 if above90<=25 else 0
    score += 8 if 30<=rsi_val<=62 and rsi_val>prior_rsi else 4 if 30<=rsi_val<=70 else 0
    score += 8 if hist_inc else 0
    score += 8 if price_reversal and three_day_up else 4 if price_reversal else 0
    score += 6 if relative_vol>=1.2 else 3 if relative_vol>=0.8 else 0
    score += 7 if np.isfinite(rs21) and rs21>0 else 0
    score += 3 if spot>sma50 else 0
    score += 3 if spot>sma200 else 0
    score = min(80,int(score))
    issues = []
    if not(settings.min_stock_price <= spot <= settings.max_stock_price):
        issues.append('Outside stock price range')
    if above90 > settings.max_above_90d_low_pct:
        issues.append('Too far above 90-day low')
    if len(near) < settings.minimum_support_windows:
        issues.append('Insufficient support confluence')
    if touches < settings.minimum_support_touches:
        issues.append('Insufficient prior support tests')
    if settings.require_higher_timeframe_support and higher_hits<1:
        issues.append('No completed weekly/monthly support alignment')
    if age_days > 7 or age_days < 0:
        issues.append('Price history stale or date inconsistent')
    bounce = bool(price_reversal and hist_inc)
    status = 'SETUP' if not issues and bounce else 'WATCH' if not issues else 'NO MATCH'
    if not bounce and not issues:
        issues.append('Await price and MACD confirmation')
    result = {'Ticker':symbol, 'Status': status, 'Technical score /80':score,
       'Price':round(spot,2), 'Last bar':last_day, 'Days old':age_days,
       'Above 90d low %':round(above90,2), 'Confluence':len(near),
       'Support windows':','.join(str(n) for n in near) or 'None',
       'Support zone $':round(nearest_level,2), 'Prior touches':touches,
       'Weekly support $':round(weekly_level,2) if np.isfinite(weekly_level) else None,
       'Monthly support $':round(monthly_level,2) if np.isfinite(monthly_level) else None,
       'Weekly support gap %':round(weekly_gap,2) if np.isfinite(weekly_gap) else None,
       'Monthly support gap %':round(monthly_gap,2) if np.isfinite(monthly_gap) else None,
       'Higher TF confluence':higher_hits,
       'Support gap %':round((spot/nearest_level-1)*100,2),
       'RSI14':round(rsi_val,1), 'RSI rising':bool(rsi_val>prior_rsi),
       'MACD improving':hist_inc, 'Bullish candle':price_reversal,
       'Relative volume':round(relative_vol,2), 'vs SPY 21d %':round(rs21,2),
       'Above SMA50': bool(spot>sma50), 'Above SMA200':bool(spot>sma200),
       'Realized volatility 20d':round(rv20,4) if np.isfinite(rv20) else None,
       'Reason': '; '.join(issues) if issues else 'All setup gates met'}
    return result


def fundamental_analysis(info: dict, sector_change: Optional[float] = None) -> dict:
    """Unknown inputs never silently count as favorable."""
    if not isinstance(info,dict): info={}
    growth = fnum(info.get('revenueGrowth'))
    profit = fnum(info.get('profitMargins'))
    fcf = fnum(info.get('freeCashflow'))
    cash = fnum(info.get('totalCash'))
    debt = fnum(info.get('totalDebt'))
    sector = str(info.get('sector') or 'Unknown')
    cap = fnum(info.get('marketCap'))
    trailing_pe=fnum(info.get('trailingPE'))
    forward_pe=fnum(info.get('forwardPE'))
    ps=fnum(info.get('priceToSalesTrailing12Months'))
    earnings_growth=fnum(info.get('earningsGrowth'))
    components = {'Revenue growth':growth, 'Profit margin':profit, 'Free cash flow':fcf,
                  'Cash':cash, 'Debt':debt, 'Sector performance':sector_change}
    available = sum(np.isfinite(fnum(v)) for v in components.values())
    score = 0
    if np.isfinite(growth) and growth > 0: score += 3
    if np.isfinite(profit) and profit > 0: score += 3
    if np.isfinite(fcf) and fcf > 0: score += 3
    if np.isfinite(cash) and np.isfinite(debt) and cash >= debt: score += 1
    if sector_change is not None and np.isfinite(fnum(sector_change)) and sector_change > 0: score += 2
    return {'Fundamental score /12':score, 'Fundamental coverage':f'{available}/6',
            'Revenue growth %':round(growth*100,1) if np.isfinite(growth) else None,
            'Profit margin %':round(profit*100,1) if np.isfinite(profit) else None,
            'Free cash flow $':round(fcf,0) if np.isfinite(fcf) else None,
            'Sector':sector, 'Market cap $':round(cap,0) if np.isfinite(cap) else None,
            'Trailing P/E':round(trailing_pe,2) if np.isfinite(trailing_pe) else None,
            'Forward P/E':round(forward_pe,2) if np.isfinite(forward_pe) else None,
            'Price / sales':round(ps,2) if np.isfinite(ps) else None,
            'Earnings growth %':round(earnings_growth*100,1) if np.isfinite(earnings_growth) else None,
            'Sector vs SPY 21d %':round(sector_change,1) if sector_change is not None else None}


def extract_earnings_date(info:dict, calendar=None) -> Optional[date]:
    """Provider information is incomplete: returns None unless date clearly in future."""
    possible = []
    for key in ('earningsTimestamp', 'earningsTimestampStart','earningsDate'):
        value = info.get(key)
        if isinstance(value,(int,float)) and value>1_000_000_000:
            possible.append(datetime.fromtimestamp(value,timezone.utc).date())
    if isinstance(calendar,dict):
        val = calendar.get('Earnings Date') or calendar.get('EarningsDate')
        if not isinstance(val,(list,tuple)): val=[val]
        for item in val:
            try: possible.append(pd.Timestamp(item).date())
            except Exception: pass
    valid = [x for x in possible if x>=datetime.now(timezone.utc).date()]
    return min(valid) if valid else None


def evaluate_option_chain(symbol: str, expiration: str, calls: pd.DataFrame, spot: float,
                          rv20: float, settings:Settings, earnings_date=None, today=None):
    today = today or datetime.now(timezone.utc).date()
    expiry = date.fromisoformat(expiration)
    dte = (expiry-today).days
    results=[]
    if calls is None or calls.empty: return results
    for _, c in calls.iterrows():
        strike,bid,ask,iv = (fnum(c.get(q)) for q in ('strike','bid','ask','impliedVolatility'))
        if any(not np.isfinite(v) for v in (strike,bid,ask,iv)) or not (ask>0 and bid>0 and ask>=bid and iv>.005):
            continue
        if strike >= spot: continue  # this profile explicitly prefers ITM calls
        mid=(bid+ask)/2
        spread=(ask-bid)/mid*100
        cost=ask*100  # worst case ask, excluding fees
        open_int=fnum(c.get('openInterest'),0)
        vol=fnum(c.get('volume'),0)
        greek=black_scholes_call(spot,strike,max(dte,1)/365,iv,settings.interest_rate)
        delta=greek['delta']
        ratio=iv/rv20 if np.isfinite(rv20) and rv20>.001 else float('nan')
        notes=[]
        if not(settings.min_dte<=dte<=settings.max_dte): notes.append('DTE')
        if cost>settings.hard_premium_cap: notes.append('Exceeds premium / full-loss risk cap')
        if not(settings.min_delta<=delta<=settings.max_delta): notes.append('Delta')
        if spread>settings.max_spread_pct: notes.append('Spread')
        if open_int<settings.min_open_interest: notes.append('Open interest')
        if np.isfinite(ratio) and ratio>settings.max_iv_rv_ratio: notes.append('IV versus realized volatility')
        if not np.isfinite(ratio): notes.append('IV/RV unavailable')
        days_to_earn=(earnings_date-today).days if earnings_date else None
        earnings_flag=('UPCOMING' if days_to_earn is not None and 0<=days_to_earn<=dte
                      else 'Known date after expiry' if earnings_date else 'UNVERIFIED')
        if earnings_flag=='UPCOMING': notes.append('Earnings within contract life: review')
        option_points = (3 if .62<=delta<=.70 else 2 if settings.min_delta<=delta<=settings.max_delta else 0)
        option_points += (3 if spread<=8 else 2 if spread<=settings.max_spread_pct else 0)
        option_points += (1 if open_int>=settings.min_open_interest else 0)
        option_points += (1 if np.isfinite(ratio) and ratio<=1.5 else 0)
        results.append({'Ticker':symbol,'Expiration':expiration,'DTE':dte,'Strike':strike,
            'Bid':round(bid,2), 'Ask':round(ask,2), 'Mid':round(mid,2),
            'Max loss 1 contract $':round(cost,2),'Delta (model)':round(delta,3),
            'Theta/day (model)':round(greek['theta_day'],4),
            'Vega /1% IV (model)':round(greek['vega_1pct'],4),
            'IV %':round(iv*100,1), 'IV / RV20':round(ratio,2) if np.isfinite(ratio) else None,
            'Spread %':round(spread,1), 'Open interest':int(open_int), 'Option volume':int(vol),
            'Breakeven at expiry $':round(strike+ask,2),
            'Earnings risk':earnings_flag,
            'Contract score /8':option_points,
            'Contract status':'REVIEW' if not notes else 'REJECTED',
            'Reject / review reasons':'; '.join(notes) if notes else 'Earnings, news, catalysts, and quote freshness require independent verification',
            'Contract symbol':str(c.get('contractSymbol') or '')})
    return results


def option_scenarios(spot, strike, iv, ask, dte, interest_rate=0.04, days_passed=30):
    rows=[]
    days_passed=min(max(0,int(days_passed)),int(dte))
    for stock_move in (-10,-5,0,5,10):
        for iv_points in (-10,0,10):
            s=spot*(1+stock_move/100)
            v=max(0.01,iv+iv_points/100)
            t=max(0,(dte-days_passed)/365)
            new_value=black_scholes_call(s,strike,t,v,interest_rate)['value']
            pnl=(new_value-ask)*100
            rows.append({'Stock move %':stock_move,'IV change (points)':iv_points,
                'Days elapsed':days_passed,'Estimated option $':round(new_value*100,2),
                'P/L per contract $':round(pnl,2),'P/L %':round((new_value/ask-1)*100,1)})
    return pd.DataFrame(rows)


def journal_stats(closed:pd.DataFrame):
    if closed is None or closed.empty or 'Realized P/L $' not in closed: return None
    pnl=pd.to_numeric(closed['Realized P/L $'], errors='coerce').dropna()
    if pnl.empty: return None
    win=pnl[pnl>0]; loss=pnl[pnl<0]
    wins=float(win.sum()); losses=float(-loss.sum())
    equity=pnl.cumsum()
    drawdown=equity-equity.cummax().clip(lower=0)
    return {'Trades':len(pnl),'Win rate %':round(len(win)/len(pnl)*100,1),
            'Expectancy $/trade':round(float(pnl.mean()),2),
            'Profit factor':round(wins/losses,2) if losses>0 else None,
            'Total P/L $':round(float(pnl.sum()),2),
            'Max peak-to-trough drawdown $':round(float(drawdown.min()),2)}
