"""Network adapter. Yahoo/yfinance is unofficial and can fail or return delayed data."""
from __future__ import annotations
from datetime import datetime, timezone
import pandas as pd

from core import (Settings, extract_earnings_date, evaluate_option_chain,
                  fundamental_analysis, price_analysis, fnum)

# Sector ETF proxies are approximate, not perfect company-specific peers.
SECTOR_ETFS={
 'Technology':'XLK','Financial Services':'XLF','Energy':'XLE',
 'Healthcare':'XLV','Consumer Cyclical':'XLY','Consumer Defensive':'XLP',
 'Industrials':'XLI','Utilities':'XLU','Basic Materials':'XLB',
 'Real Estate':'XLRE','Communication Services':'XLC'}

DEFAULT_WATCHLIST=(
 'AAPL MSFT NVDA AMD INTC GOOGL AMZN META TSLA MU PLTR SOFI HOOD NU PYPL '
 'DKNG UBER RBLX SNAP PINS TSM ARM SMCI COIN RIVN F ROKU SHOP SQ '
 'BAC C CCL DAL NIO IONQ HIMS PATH UPST CRWD NET MARA CLSK'
)


def clean_symbols(raw: str):
    seen=set(); symbols=[]
    for raw_one in raw.replace(',',' ').replace(';',' ').replace('\n',' ').split():
        s=raw_one.strip().upper()
        if s and s not in seen and len(s)<=12 and all(x.isalnum() or x in '.-^' for x in s):
            symbols.append(s);seen.add(s)
    return symbols


def fetch_histories(symbols, period='18mo'):
    import yfinance as yf
    symbols=list(dict.fromkeys(symbols))
    try:
        bulk=yf.download(symbols,period=period,interval='1d',auto_adjust=True,
                         group_by='ticker',threads=True,progress=False)
    except Exception as exc:
        raise RuntimeError(f'Bulk historical download failed: {exc}') from exc
    out={}
    for symbol in symbols:
        try:
            if isinstance(bulk.columns,pd.MultiIndex):
                # group_by=ticker -> first dimension is ticker, regardless of sort order.
                if symbol in bulk.columns.get_level_values(0):
                    h=bulk[symbol]
                elif symbol in bulk.columns.get_level_values(1):
                    h=bulk.xs(symbol,axis=1,level=1)
                else: continue
            else:
                if len(symbols)!=1: continue
                h=bulk
            h=h.dropna(subset=['Close']).copy()
            if not h.empty: out[symbol]=h
        except (KeyError,TypeError,ValueError): pass
    return out


def _get_info_and_calendar(ticker):
    try: info=ticker.info or {}
    except Exception: info={}
    try: calendar=ticker.calendar
    except Exception: calendar=None
    return info, calendar


def _ret21(hist):
    if hist is None or hist.empty or len(hist)<22: return None
    a=fnum(hist['Close'].iloc[-1]); b=fnum(hist['Close'].iloc[-22])
    return (a/b-1)*100 if b>0 else None


def fetch_stock_results(symbols, settings:Settings, progress=None):
    """Stage 1: price screen for ALL stocks, info only for shortlisted matches."""
    import yfinance as yf
    benchmarks=['SPY']+list(SECTOR_ETFS.values())
    price_map=fetch_histories(list(dict.fromkeys(symbols+benchmarks)))
    spy=price_map.get('SPY')
    stock_rows=[]; errors=[]
    for i,symbol in enumerate(symbols):
        if progress: progress((i+1)/max(1,len(symbols))*0.60,f'Price scan {i+1}/{len(symbols)} — {symbol}')
        try:
            row=price_analysis(symbol,price_map.get(symbol),spy,settings)
            stock_rows.append(row)
            if row['Status']=='DATA ERROR': errors.append(f"{symbol}: {row['Reason']}")
        except Exception as exc:
            errors.append(f'{symbol}: {exc}')
            stock_rows.append({'Ticker':symbol,'Status':'DATA ERROR','Reason':str(exc)})
    stocks=pd.DataFrame(stock_rows)
    if stocks.empty: return stocks,{},price_map,errors
    if 'Technical score /80' not in stocks:
        stocks['Technical score /80']=float('nan')
    stocks=stocks.sort_values(by=['Technical score /80'],ascending=False,na_position='last')
    # Only a bounded number of near-setups receive expensive fundamental lookups.
    shortlist=stocks.loc[stocks['Status'].isin(['SETUP','WATCH']),'Ticker'].head(max(15,settings.max_option_stocks*2)).tolist()
    info_by_symbol={}
    for i,symbol in enumerate(shortlist):
        if progress: progress(.60+(i+1)/max(1,len(shortlist))*.30,f'Fundamentals {i+1}/{len(shortlist)} — {symbol}')
        try:
            ticker=yf.Ticker(symbol)
            info,cal=_get_info_and_calendar(ticker)
            info_by_symbol[symbol]=(info,cal)
            sector=info.get('sector','')
            sector_etf=SECTOR_ETFS.get(sector)
            sector_ret=_ret21(price_map.get(sector_etf)) if sector_etf else None
            spy_ret=_ret21(spy)
            sector_delta=sector_ret-spy_ret if sector_ret is not None and spy_ret is not None else None
            fundament=fundamental_analysis(info,sector_delta)
            earning=extract_earnings_date(info,cal)
            for key,value in fundament.items():stocks.loc[stocks['Ticker']==symbol,key]=value
            stocks.loc[stocks['Ticker']==symbol,'Upcoming earnings']=str(earning) if earning else 'Unverified'
        except Exception as exc:
            errors.append(f'{symbol} fundamentals: {exc}')
    if 'Fundamental score /12' not in stocks:
        stocks['Fundamental score /12']=float('nan')
    stocks['Fundamental score /12']=pd.to_numeric(stocks['Fundamental score /12'],errors='coerce').fillna(0)
    stocks['Combined score /100']=stocks['Technical score /80'].fillna(0)+stocks['Fundamental score /12']
    stocks=stocks.sort_values(by=['Combined score /100'],ascending=False,na_position='last').reset_index(drop=True)
    if progress: progress(.90,'Price and fundamental stages complete')
    return stocks,info_by_symbol,price_map,errors


def fetch_options(stocks:pd.DataFrame, info_by_symbol:dict, settings:Settings, progress=None):
    import yfinance as yf
    if stocks.empty: return pd.DataFrame(),[]
    matching_status=['SETUP','WATCH'] if settings.include_watch else ['SETUP']
    picks=stocks[stocks['Status'].isin(matching_status)].head(settings.max_option_stocks)
    rows=[]; errors=[]; today=datetime.now(timezone.utc).date()
    for idx,(_,row) in enumerate(picks.iterrows()):
        symbol=row['Ticker']
        if progress: progress((idx+1)/max(1,len(picks)),f'Inspecting call chains: {symbol}')
        try:
            obj=yf.Ticker(symbol)
            available=[]
            for d in obj.options:
                try:
                    dte=(datetime.strptime(d,'%Y-%m-%d').date()-today).days
                    if settings.min_dte<=dte<=settings.max_dte: available.append((d,dte))
                except Exception: pass
            center=(settings.min_dte+settings.max_dte)/2
            # Select expirations spread across desired holding times, rather than nearest only.
            available.sort(key=lambda item: item[1])
            if len(available)>settings.max_expirations_per_stock:
                indices={round(i*(len(available)-1)/(settings.max_expirations_per_stock-1))
                         for i in range(settings.max_expirations_per_stock)} if settings.max_expirations_per_stock>1 else {0}
                available=[item for i,item in enumerate(available) if i in indices]
            if not available:
                errors.append(f'{symbol}: no expiration in selected DTE range')
                continue
            info,cal=info_by_symbol.get(symbol,({},None))
            earnings=extract_earnings_date(info,cal)
            rv=fnum(row.get('Realized volatility 20d'))
            for expiry,dte in available:
                try:
                    calls=obj.option_chain(expiry).calls
                    rows.extend(evaluate_option_chain(symbol,expiry,calls,float(row['Price']),rv,settings,
                                                      earnings_date=earnings,today=today))
                except Exception as exc:errors.append(f'{symbol} {expiry}: {exc}')
        except Exception as exc:errors.append(f'{symbol} option chain: {exc}')
    if not rows: return pd.DataFrame(),errors
    options=pd.DataFrame(rows)
    # Earnings and other events remain a separate manual-review gate.
    scores=stocks.set_index('Ticker')['Combined score /100']
    options['Combined score /100']=options['Ticker'].map(scores).fillna(0)+options['Contract score /8']
    options=options.sort_values(by=['Contract status','Combined score /100','Spread %'],
                                ascending=[False,False,True]).reset_index(drop=True)
    return options,errors
